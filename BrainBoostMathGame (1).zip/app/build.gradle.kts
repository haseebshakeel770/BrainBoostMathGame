plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.brainboost.mathgame"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.brainboost.mathgame"
        minSdk = 23; targetSdk = 34; versionCode = 1; versionName = "1.0"
    }
    buildFeatures { buildConfig = true }
    buildTypes {
        debug { buildConfigField("boolean", "TEST_MODE", "true") }
        release {
            buildConfigField("boolean", "TEST_MODE", "false")
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("com.unity3d.ads:unity-ads:4.12.5") }
