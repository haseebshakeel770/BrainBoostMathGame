package com.brainboost.mathgame

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.os.*
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.widget.*
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize
import kotlin.random.Random

private val GOLD = 0xFFFFC107.toInt(); private val GOLDD = 0xFFC79100.toInt()
private val PURPLE = 0xFF7C4DFF.toInt(); private val CYAN = 0xFF00A5C0.toInt()
private val BLUE = 0xFF3F5BD9.toInt(); private val PINK = 0xFFD81B8A.toInt()
private val GREEN = 0xFF2EAD4B.toInt(); private val RED = 0xFFD32F2F.toInt()
private val NAMES = arrayOf("Easy", "Medium", "Hard")

data class Q(val text: String, val ans: Int, val opts: List<Int>)

class Wheel(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cols = intArrayOf(0xFF7C4DFF.toInt(), 0xFF00A5C0.toInt(), 0xFFD81B8A.toInt(), 0xFF3F5BD9.toInt(), 0xFF2EAD4B.toInt(), 0xFFC79100.toInt())
    override fun onMeasure(w: Int, h: Int) { val s = MeasureSpec.getSize(w) * 7 / 10; setMeasuredDimension(s, s) }
    override fun onDraw(cv: Canvas) {
        val s = width.toFloat(); val r = RectF(8f, 8f, s - 8, s - 8)
        for (i in 0..5) {
            p.style = Paint.Style.FILL; p.color = cols[i]; cv.drawArc(r, -90f + 60 * i, 60f, true, p)
            p.color = Color.WHITE; p.textSize = s / 11; p.textAlign = Paint.Align.CENTER; p.isFakeBoldText = true
            val a = Math.toRadians((-90 + 60 * i + 30).toDouble())
            cv.drawText("${Config.WHEEL[i]}", s / 2 + (s * 0.33 * Math.cos(a)).toFloat(), s / 2 + (s * 0.33 * Math.sin(a)).toFloat() + p.textSize / 3, p)
        }
    }
}

class MainActivity : Activity() {
    private lateinit var st: Store
    private val h = Handler(Looper.getMainLooper())
    private var tone: ToneGenerator? = null
    private var onHome = true; private var spinning = false
    private var level = 1; private var qs: List<Q> = emptyList(); private var idx = 0; private var score = 0
    private var elapsed = 0; private var done = 0; private var timerTv: TextView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store(this)
        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (e: Exception) { null }
        Ads.init(this); home()
    }
    override fun onBackPressed() { if (spinning) return; if (onHome) super.onBackPressed() else home() }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun beep(ok: Boolean) { if (st.sound) tone?.startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 150) }
    private fun fmt(s: Int) = "%d:%02d".format(s / 60, s % 60)
    private fun tv(t: String, s: Float = 18f, c: Int = Color.WHITE, b: Boolean = false) = TextView(this).apply {
        text = t; textSize = s; setTextColor(c); gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), dp(4))
        if (b) setTypeface(null, Typeface.BOLD)
    }
    private fun Button.tint(c: Int) { (background as GradientDrawable).setColor(c) }
    private fun btn(t: String, c: Int = PURPLE, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 17f
        background = GradientDrawable().apply { cornerRadius = dp(26).toFloat(); setColor(c) }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(dp(24), dp(6), dp(24), dp(6)) }
        setOnClickListener { f() }
    }
    private fun screen(banner: Boolean = false, build: LinearLayout.() -> Unit) {
        h.removeCallbacksAndMessages(null); onHome = false
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(24), 0, dp(16)); build() }
        val sv = ScrollView(this).apply { isFillViewport = true; addView(col) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF0D1B4C.toInt(), 0xFF4A1FA8.toInt()))
            addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        if (banner) {
            val bv = BannerView(this, AdConfig.BANNER, UnityBannerSize(320, 50)); bv.load()
            root.addView(bv, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        }
        setContentView(root)
    }

    // ---------- screens ----------
    private fun home() {
        screen(true) {
            addView(tv("🧠", 60f)); addView(tv("Brain Boost\nMath Game", 30f, GOLD, true)); addView(tv("🪙 ${st.coins} Coins", 22f))
            addView(btn("▶  Play Now") { start((1..Config.LEVELS).firstOrNull { st.stars(it) == 0 && st.unlocked(it) } ?: 1) })
            addView(btn("Select Level", CYAN) { levels() })
            addView(btn("Difficulty: ${NAMES[st.diff]}", BLUE) { st.diff = (st.diff + 1) % 3; home() })
            addView(btn(if (st.claimedDaily()) "Daily Reward: Claimed" else "🎁 Daily Reward +${Config.DAILY}", GOLDD) {
                if (!st.claimedDaily()) { st.claimDaily(); st.coins += Config.DAILY; beep(true) }; home()
            })
            addView(btn("🎡 Lucky Wheel", PINK) { wheel() })
            addView(btn("Statistics", BLUE) { stats() }); addView(btn("Settings", BLUE) { settings() })
        }
        onHome = true
    }

    private fun levels(): Unit = screen(true) {
        addView(tv("Select Level", 26f, GOLD, true)); addView(tv("🪙 ${st.coins}   •   ${NAMES[st.diff]}", 18f))
        for (r in 0 until Config.LEVELS / 5) {
            val row = LinearLayout(this@MainActivity)
            for (c in 0 until 5) {
                val l = r * 5 + c + 1; val u = st.unlocked(l); val s = st.stars(l)
                row.addView(Button(this@MainActivity).apply {
                    isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
                    text = if (u) "$l\n" + "★".repeat(s) + "☆".repeat(3 - s) else "🔒$l\n${Config.cost(l)}🪙"
                    background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(if (u) PURPLE else 0xFF555577.toInt()) }
                    setOnClickListener { if (u) start(l) else askUnlock(l) }
                }, LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(8), 0, dp(8), 0) })
        }
        addView(btn("Back") { home() })
    }

    private fun askUnlock(l: Int) {
        val c = Config.cost(l)
        AlertDialog.Builder(this).setTitle("Unlock Level $l").setMessage("Cost: $c coins (you have ${st.coins})")
            .setPositiveButton("Unlock") { _, _ ->
                if (st.coins >= c) { st.coins -= c; st.unlock(l); beep(true); levels() } else toast("Not enough coins")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun genQs(l: Int, d: Int): List<Q> {
        val n = Config.count(l); val out = ArrayList<Q>(); val seen = HashSet<String>()
        val s = 6 + d * 6 + l * 2; val mm = minOf(5 + d * 2 + l / 6, 25); var tries = 0
        while (out.size < n && tries < 500) {
            tries++
            val (t, ans) = when (Random.nextInt(4)) {
                0 -> { val a = Random.nextInt(1, s + 1); val b = Random.nextInt(1, s + 1); "$a + $b" to a + b }
                1 -> { val a = Random.nextInt(2, s * 2 + 1); val b = Random.nextInt(1, a); "$a − $b" to a - b }
                2 -> { val a = Random.nextInt(2, mm + 1); val b = Random.nextInt(2, mm + 1); "$a × $b" to a * b }
                else -> { val b = Random.nextInt(2, minOf(4 + d + l / 10, 15) + 1); val q = Random.nextInt(2, mm + 1); "${b * q} ÷ $b" to q }
            }
            if (!seen.add(t)) continue
            val o = mutableSetOf(ans)
            while (o.size < 4) { val v = ans + Random.nextInt(-10, 11); if (v >= 0) o.add(v) }
            out.add(Q(t, ans, o.shuffled()))
        }
        return out
    }

    private fun start(l: Int) {
        level = l; qs = genQs(l, st.diff); idx = 0; score = 0; elapsed = 0; question()
    }

    private fun tick(): Boolean = h.postDelayed({ elapsed++; timerTv?.text = "⏱ ${fmt(elapsed)}"; tick() }, 1000)

    private fun question() {
        val q = qs[idx]
        screen {
            addView(tv("Level $level • ${NAMES[st.diff]}", 16f, CYAN))
            timerTv = tv("⏱ ${fmt(elapsed)}", 18f); addView(timerTv)
            addView(tv("Question ${idx + 1}/${qs.size}   Score $score", 18f))
            addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply { max = qs.size; progress = idx },
                LinearLayout.LayoutParams(-1, dp(12)).apply { setMargins(dp(24), dp(8), dp(24), dp(24)) })
            addView(tv(q.text, 44f, GOLD, true)); addView(Space(this@MainActivity), LinearLayout.LayoutParams(-1, dp(24)))
            val bs = q.opts.map { o -> btn("$o") {}.apply { tag = o } }
            bs.forEach { b -> b.setOnClickListener { answer(q, b.tag as Int, b, bs) }; addView(b) }
            addView(btn("Quit", 0xFF884444.toInt()) { levels() })
            tick()
        }
    }

    private fun answer(q: Q, v: Int, b: Button, all: List<Button>) {
        all.forEach { it.isEnabled = false }
        if (v == q.ans) { score++; st.correct++; beep(true); b.tint(GREEN) }
        else { st.wrong++; beep(false); b.tint(RED); all.first { it.tag == q.ans }.tint(GREEN); toast("Correct answer: ${q.ans}") }
        h.postDelayed({ idx++; if (idx < qs.size) question() else finishLevel() }, 800)
    }

    private fun finishLevel() {
        val pct = score * 100 / qs.size; val ok = pct >= 60
        val stars = if (pct == 100) 3 else if (pct >= 80) 2 else if (ok) 1 else 0
        st.played++; var coins = 0
        if (ok) { coins = Config.REWARD[st.diff]; st.coins += coins; st.setStars(level, stars) }
        if (ok && ++done % 3 == 0) Ads.show(this, AdConfig.INTERSTITIAL) { result(ok, stars, coins) } else result(ok, stars, coins)
    }

    private fun result(ok: Boolean, stars: Int, coins: Int) {
        var doubled = false
        screen {
            addView(tv(if (ok) "Level Complete!" else "Try Again", 30f, if (ok) GOLD else RED, true))
            addView(tv("★".repeat(stars) + "☆".repeat(3 - stars), 40f, GOLD))
            addView(tv("Correct: $score/${qs.size}   Time: ${fmt(elapsed)}", 18f))
            if (ok) {
                addView(tv("+$coins 🪙", 26f))
                val d = btn("🎬 Watch Ad: Double Coins (+$coins)", GOLDD) {}
                d.setOnClickListener {
                    Ads.show(this@MainActivity, AdConfig.REWARDED) { w ->
                        if (w && !doubled) { doubled = true; st.coins += coins; d.isEnabled = false; d.text = "Doubled ✔"; beep(true) }
                        else if (!w) toast("Ad not ready, try again")
                    }
                }
                addView(d)
            }
            addView(btn("Retry", CYAN) { start(level) })
            if (ok && level < Config.LEVELS && st.unlocked(level + 1)) addView(btn("Next Level") { start(level + 1) })
            addView(btn("Levels", BLUE) { levels() })
        }
    }

    private fun wheel(): Unit = screen {
        val fl = 3 - st.freeUsed; val al = 3 - st.adUsed
        addView(tv("🎡 Lucky Wheel", 28f, GOLD, true)); addView(tv("🪙 ${st.coins}", 20f))
        addView(tv("Free spins left: $fl   •   Ad spins left: $al", 16f)); addView(tv("▼", 30f, GOLD))
        val w = Wheel(this@MainActivity); addView(w)
        addView(btn(if (fl > 0) "SPIN (Free)" else "SPIN (Watch Ad)", PINK) {
            if (spinning) return@btn
            if (fl > 0) { st.freeUsed = st.freeUsed + 1; doSpin(w) }
            else if (al > 0) Ads.show(this@MainActivity, AdConfig.REWARDED) { ok ->
                if (ok) { st.adUsed = st.adUsed + 1; doSpin(w) } else toast("Ad not ready, try again")
            } else toast("No spins left today. Come back tomorrow!")
        })
        addView(btn("Back", BLUE) { home() })
    }

    private fun doSpin(w: Wheel) {
        spinning = true; val i = Random.nextInt(6); val cur = w.rotation
        val target = cur - cur % 360 + 360 * 5 + 360 - (i * 60 + 30)
        w.animate().rotation(target).setDuration(3500).setInterpolator(DecelerateInterpolator()).withEndAction {
            spinning = false; st.coins += Config.WHEEL[i]; beep(true)
            AlertDialog.Builder(this).setTitle("🎉 You won!").setMessage("+${Config.WHEEL[i]} coins").setCancelable(false)
                .setPositiveButton("OK") { _, _ -> wheel() }.show()
        }.start()
    }

    private fun stats(): Unit = screen {
        addView(tv("Statistics", 28f, GOLD, true))
        val done = (1..Config.LEVELS).count { st.stars(it) > 0 }
        val stars = (1..Config.LEVELS).sumOf { st.stars(it) }
        addView(tv("Levels completed: $done / ${Config.LEVELS}\nTotal stars: $stars\nLevels played: ${st.played}\nCorrect answers: ${st.correct}\nWrong answers: ${st.wrong}\nCoins: ${st.coins}", 20f))
        addView(btn("Back") { home() })
    }

    private fun settings(): Unit = screen {
        addView(tv("Settings", 28f, GOLD, true))
        addView(btn("Sound: ${if (st.sound) "ON" else "OFF"}", CYAN) { st.sound = !st.sound; settings() })
        addView(tv("Ads mode: ${if (BuildConfig.TEST_MODE) "TEST" else "LIVE"}", 16f))
        addView(btn("Back") { home() })
    }
}
