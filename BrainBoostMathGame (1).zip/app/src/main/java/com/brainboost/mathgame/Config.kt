package com.brainboost.mathgame

// Unity Ads IDs. Change here if your dashboard names differ.
object AdConfig {
    const val GAME_ID = "6224801"
    const val REWARDED = "Rewarded_Android"
    const val INTERSTITIAL = "Interstitial_Android"
    const val BANNER = "Banner_Android"
}

// Game balance. Edit freely.
object Config {
    val REWARD = intArrayOf(20, 35, 50)          // Easy, Medium, Hard coins per passed level
    const val DAILY = 50
    val WHEEL = intArrayOf(10, 20, 30, 50, 100, 200)
    fun cost(l: Int) = if (l <= 3) 0 else 10 + l * 4   // unlock cost per level
    fun count(l: Int) = 10 + (l - 1) / 12              // questions per level (10..18)
}
