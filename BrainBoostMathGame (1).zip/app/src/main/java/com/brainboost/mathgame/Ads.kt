package com.brainboost.mathgame

import android.app.Activity
import com.unity3d.ads.*

object Ads {
    private val loaded = HashSet<String>()

    fun init(a: Activity) {
        UnityAds.initialize(a.applicationContext, AdConfig.GAME_ID, BuildConfig.TEST_MODE, object : IUnityAdsInitializationListener {
            override fun onInitializationComplete() { load(AdConfig.REWARDED); load(AdConfig.INTERSTITIAL) }
            override fun onInitializationFailed(e: UnityAds.UnityAdsInitializationError?, m: String?) {}
        })
    }

    fun load(id: String) {
        UnityAds.load(id, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(p: String?) { if (p != null) loaded.add(p) }
            override fun onUnityAdsFailedToLoad(p: String?, e: UnityAds.UnityAdsLoadError?, m: String?) {}
        })
    }

    // onDone(true) only when the ad was fully watched (COMPLETED)
    fun show(a: Activity, id: String, onDone: (Boolean) -> Unit) {
        if (!loaded.remove(id)) { load(id); onDone(false); return }
        UnityAds.show(a, id, UnityAdsShowOptions(), object : IUnityAdsShowListener {
            override fun onUnityAdsShowFailure(p: String?, e: UnityAds.UnityAdsShowError?, m: String?) { load(id); onDone(false) }
            override fun onUnityAdsShowStart(p: String?) {}
            override fun onUnityAdsShowClick(p: String?) {}
            override fun onUnityAdsShowComplete(p: String?, s: UnityAds.UnityAdsShowCompletionState?) {
                load(id); onDone(s == UnityAds.UnityAdsShowCompletionState.COMPLETED)
            }
        })
    }
}
