# Brain Boost Math Game
Native Android (Kotlin). Unity Ads: Rewarded + Interstitial + Banner. Android Game ID 6224801.

## Build
Upload all files to GitHub (main branch). Actions -> "Build APK" -> download artifact BrainBoost-APKs.
Debug APK = Unity TEST ads. Release APK = LIVE ads (testMode false), signed with debug key.

## Ad IDs
Edit `app/src/main/java/com/brainboost/mathgame/Config.kt` (AdConfig) if your Unity dashboard names differ.

## Balance
Coins, unlock costs, wheel values: `Config.kt`.
