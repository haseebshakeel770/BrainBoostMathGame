package com.brainboost.mathgame

import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

class Store(c: Context) {
    private val p = c.getSharedPreferences("bb", 0)
    private fun gi(k: String) = p.getInt(k, 0)
    private fun pi(k: String, v: Int) = p.edit().putInt(k, v).apply()
    var coins: Int get() = gi("coins"); set(v) { pi("coins", v) }
    var diff: Int get() = gi("diff"); set(v) { pi("diff", v) }
    var correct: Int get() = gi("cor"); set(v) { pi("cor", v) }
    var wrong: Int get() = gi("wr"); set(v) { pi("wr", v) }
    var played: Int get() = gi("pl"); set(v) { pi("pl", v) }
    var sound: Boolean get() = p.getBoolean("snd", true); set(v) { p.edit().putBoolean("snd", v).apply() }
    fun stars(l: Int) = gi("s$l")
    fun setStars(l: Int, v: Int) { if (v > stars(l)) pi("s$l", v) }
    fun unlocked(l: Int) = Config.cost(l) == 0 || p.getBoolean("u$l", false)
    fun unlock(l: Int) { p.edit().putBoolean("u$l", true).apply() }

    // Date never goes backwards (blocks clock-change abuse)
    fun today(): String {
        val n = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val m = p.getString("maxd", "") ?: ""
        val t = if (n < m) m else n
        p.edit().putString("maxd", t).apply()
        return t
    }
    private fun roll() {
        val t = today()
        if (p.getString("sd", "") != t) p.edit().putString("sd", t).putInt("fu", 0).putInt("au", 0).apply()
    }
    var freeUsed: Int get() { roll(); return gi("fu") }; set(v) { pi("fu", v) }
    var adUsed: Int get() { roll(); return gi("au") }; set(v) { pi("au", v) }
    fun claimedDaily() = p.getString("dd", "") == today()
    fun claimDaily() { p.edit().putString("dd", today()).apply() }
}
